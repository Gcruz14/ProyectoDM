<?php

use yii\db\Migration;

/**
 * Class m181120_184228_Comidas
 */
class m181120_184228_Comidas extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('Comidas', [
            'id' => $this->primaryKey(),
            'nombre'=>$this->string(),
            'descripcion'=>$this->string(),
            'pais'=>$this->string(),
            'img'=>$this->string(),
            'created'=>$this->timestamp(),
            'modified'=>$this->timestamp(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m181120_184228_Comidas cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m181120_184228_Comidas cannot be reverted.\n";

        return false;
    }
    */
}
