<?php

use yii\db\Migration;

/**
 * Handles the creation of table `Comidas`.
 */
class m181120_183011_create_Comidas_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('Comidas', [
            'id' => $this->primaryKey(),
            'nombre'=>$this->string(),
            'descripcion'=>$this->string(),
            'pais'=>$this->string(),
            'img'=>$this->string(),
            'created'=>$this->timestamp(),
            'modified'=>$this->timestamp(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('Comidas');
    }
}
